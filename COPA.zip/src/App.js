import React from 'react';
import './App.css';
import Header from './components/header/Header';
import Selecao from './components/selecao/Selecao';

function App() {
  return (
    <div className="App">
      <Header/>
      <Selecao/>
    </div>
  );
}

export default App;
