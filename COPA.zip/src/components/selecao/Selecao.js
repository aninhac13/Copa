import React, { useState, useEffect } from 'react';
import './style.css';

const Selecao = () => {
  const [cards, setCards] = useState([])
  const [selects, setSelects] = useState([])
  function request() {
    fetch('https://raw.githubusercontent.com/delsonvictor/testetecnico/master/equipes.json')
      .then(res => res.json())
      .then((result) => {
        setCards(result)
      }
    )
  }

  function count(element) {
    if(element.checked === true) {
      if(selects.length < 8) {
        setSelects([...selects,element.id]);
      } else {
        element.checked = false;
      }
    }
    if(element.checked === false) {
      setSelects(selects.filter((e) => (e !== element.id)))
    }
  }

  useEffect(() => {
    request();
  })
  return (
    <>
      <div className="Section-Selecao">
        <div>
          <p>Selecionados</p> <p><span>{selects.length} de {cards.length} Equipes</span></p>
        </div>
        <div>
          <button>Gerar Copa</button>
        </div>
      </div>
      <div className="Section-Selecao">
        {cards.map(card => (
          <div key={card.id} className="Card">
            <input id={card.id} type="checkbox" onClick={(e) => count(e.target)} />
            <label htmlFor={card.id}>{card.nome}</label>
          </div>
        ))}
      </div>
    </>
    );
  }
  
  export default Selecao;
  