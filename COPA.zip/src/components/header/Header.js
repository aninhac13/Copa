import React from 'react';
import './style.css';

const Header = () => {
    return (
      <header className="App-header">
        <div>
          <p className="Titulo">Copa</p>
          <h1>Fase de Seleção</h1>
          <small>Selecione 8 equipes que você deseja para a competição e depois pressione o botão GERAR COPA para prossseguir</small>
        </div>
      </header>
    )
}

export default Header;